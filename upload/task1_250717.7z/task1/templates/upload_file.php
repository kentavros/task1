
<h1>Upload files</h1>

<form action="index.php" method="post" enctype="multipart/form-data">
<input type="file" value="Select file" name="file" />
<input type="submit" value="Upload" name="upload" />
</form>



