<?
//Directory for upload;
$dir_up = 'upload';

/*for class linux*/
//$dir_up = '/usr/home/user6/public_html/MYPHP/task1/upload/';

//file upload
define("FILE_UPLOAD", "File upload saccess");


//const file_message_delete
define("MESSAGE_DEL_TRUE", "File deleted");





?>
